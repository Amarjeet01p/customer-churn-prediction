# 📉 Customer Churn Prediction

Predict which telecom customers are likely to leave and suggest actionable retention strategies using machine learning and data analysis.

## 🧠 Project Overview

This project analyzes customer behavior and predicts churn using:
- SQL for data exploration
- Python for preprocessing & modeling
- Plotly + ipywidgets or Streamlit for dashboard

## 📂 Files

| File                         | Description                          |
|------------------------------|--------------------------------------|
| `Customer_Churn_Prediction.ipynb` | Main Colab notebook with EDA, modeling, and results |
| `Telco-Customer-Churn.csv`  | Original dataset                     |
| `app.py`                    | Streamlit dashboard                  |
| `requirements.txt`          | Python dependencies                  |
| `README.md`                 | Project summary and instructions     |

## 📈 Model Performance

| Metric         | Score     |
|----------------|-----------|
| Accuracy       | ~80%      |
| Precision (Yes)| ~65%      |
| Recall (Yes)   | ~57%      |
| AUC-ROC        | **0.83**  |

## ⚙️ How to Run

1. Clone this repo or download the ZIP
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the dashboard:
   ```bash
   streamlit run app.py
   ```

## 🙋‍♂️ Author
Built with ❤️ by [Your Name]
